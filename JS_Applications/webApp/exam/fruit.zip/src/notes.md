## Content

### Home Page (Static, optional)
### Catalog
### Details
- Edit
-Delete
### Create 
### Edit
### Login
### Register
### Bonus:
- Likes
- Comments
- Pagination
- Search
- Profile Page
- Custom Catalog

## Architecture 
- App entry point (initialize libraries and modules, dispatch navigation)
- Request module
- User session
- Data CRUD
- Views
- Util